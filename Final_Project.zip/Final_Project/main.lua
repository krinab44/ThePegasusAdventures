
-- Katie Wagner, Cayman Tisdale, Krina Bhagat, Gabriel Morgan, Nathaniel Smith
-- Final Project


local composer = require("composer")

composer.gotoScene("scene1")
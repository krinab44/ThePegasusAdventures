--config.lua

application = {
  content = {
    width = 640,
    height = 1140,
    fps = 60,
  },
}
--------------------------------
-- scene3 file
--------------------------------
local composer = require("composer")
local scene = composer.newScene()
local widget = require("widget")

local animMouth, animCaudal, animPelvic, animAnalFin, animSoftRay
local soundTable
local moveslider, mouthslider, caudalslider, pelvicslider, analfinslider, softrayslider
local mouth_sequenceData, caudal_sequenceData, pelvic_sequenceData, analfin_sequenceData, softray_sequenceData
backwards = false

local collideable = require("collideable");
local Player = collideable:new({xPos = 50, yPos = display.contentCenterY, deltaX = 0, deltaY = -300, tag = "Player", physicsType = "dynamic", HP = 3});

distanceTraveled = 0
numCollected = 0
--livesLeft = 3

distText = display.newText(distanceTraveled, 300, 60, native.systemFont, 30)
collectedText = display.newText(numCollected, 300, 110, native.systemFont, 30)
--livesText = display.newText(livesLeft, 300, 150, native.systemFont, 30)



function scene:create( event )
 
   local sceneGroup = self.view

   local opt = {
   	frames = {
			{ x = 743, y = 130, width = 603, height = 451}, -- 1. Buttercup 1
	 		{ x = 1447, y = 130, width = 603, height = 451}, -- 2. Buttercup 2
	      { x = 2151, y = 130, width = 603, height = 451}, -- 3. Buttercup 3

	   	{ x = 4266, y = 130, width = 603, height = 451}, -- 4. Snowflake  1
	   	{ x = 741, y = 832, width = 603, height = 446}, -- 5. Snowflake  2
	   	{ x = 1449, y = 832, width = 603, height = 446}, -- 6. Snowflake  3

	  		{ x = 2853, y = 832, width = 603, height = 446}, -- 7. Pumpkin 1
	    	{ x = 3560, y = 832, width = 603, height = 446}, -- 8. Pumpkin 2
	    	{ x = 4262, y = 832, width = 603, height = 446}, -- 9. Pumpkin 3
	    }
	}
	local sheet = graphics.newImageSheet("world.png", opt);

	butter_sequenceData = {
	    {name = "butterFlying", frames = {1, 2, 3, 2}, time = 1800, loopCount = 0}
	} 
	snow_sequenceData = {
	    {name = "snowFlying", frames = {4, 5, 6, 5}, time = 1800, loopCount = 0}
	}  
	pumpkin_sequenceData = {
	    {name = "pumpkinFlying", frames = {7, 8, 9, 8}, time = 1800, loopCount = 0}
	}  

	
	local butterAnims = display.newSprite(sheet, butter_sequenceData);



	-- main body image created --	
	local mainbody = display.newImage(sheet, 1); 
	sceneGroup:insert(mainbody)
	mainbody.anchorX = 0.5;
    mainbody.anchorY = 0.5;
	mainbody.x = display.contentCenterX - 30;
	mainbody.y = display.contentCenterY - 160;
	mainbody.xScale = 2;
	mainbody.yScale = 2.5;
	-- top fin image created --	
	local topfin = display.newImage(sheet, 2);
	sceneGroup:insert(topfin)
	topfin.anchorX = 0.5;
	topfin.anchorY = 0.5;
	topfin.x = display.contentCenterX + 44;
	topfin.y = display.contentCenterY - 233;
	topfin.xScale = 2;
	topfin.yScale = 2.5;
	-- animMouth sprite created --	
	animMouth = display.newSprite(sheet, mouth_sequenceData) --Good
	sceneGroup:insert(animMouth)
	animMouth.anchorX = 57.0
	animMouth.anchorY = 0.0
    animMouth.x = display.contentCenterX - 85;
    animMouth.y = display.contentCenterY - 154;
    animMouth.xScale = 2;
    animMouth.yScale = 2.5;
    -- animCaudal sprite created --
	animCaudal = display.newSprite(sheet, caudal_sequenceData) --GOOD
	sceneGroup:insert(animCaudal)
    animCaudal.anchorX = 0.01;
    animCaudal.anchorY = 0.5;
	animCaudal.x = display.contentCenterX + 112;
    animCaudal.y = display.contentCenterY - 125;
    animCaudal.xScale = 2;
    animCaudal.yScale = 2.5;
    -- animPelvic sprite created --
	animPelvic = display.newSprite(sheet, pelvic_sequenceData) --WORK ON
	sceneGroup:insert(animPelvic)
	animPelvic.anchorX = 0.5;
    animPelvic.anchorY = 0.0;
	animPelvic.x = display.contentCenterX - 40;
    animPelvic.y = display.contentCenterY - 101;
    animPelvic.xScale = 2;
    animPelvic.yScale = 2.5;
    -- animAnalFin sprite created --
	animAnalFin = display.newSprite(sheet, analfin_sequenceData) --WORK ON
	sceneGroup:insert(animAnalFin)
    animAnalFin.anchorX = 1.0;
    animAnalFin.anchorY = 0.0; 
    animAnalFin.x = display.contentCenterX + 173;
    animAnalFin.y = display.contentCenterY - 99;
    animAnalFin.xScale = 2;
    animAnalFin.yScale = 2.5;
    -- animSoftRay sprite created --
	animSoftRay = display.newSprite(sheet, softray_sequenceData) --GOOD
	sceneGroup:insert(animSoftRay)
	animSoftRay.anchorX = 0.2;
    animSoftRay.anchorY = 0.4;
	animSoftRay.x = display.contentCenterX + 88;
    animSoftRay.y = display.contentCenterY - 207;
    animSoftRay.xScale = 2;
    animSoftRay.yScale = 2.5;
    --[[ 	- animGroup created to group all individual parts of KingFossil
			- all sprites added to animGroup
    ]]
    local animGroup = display.newGroup()
	animGroup:insert(mainbody)
	animGroup:insert(topfin)

	animGroup:insert(animMouth)
	animGroup:insert(animCaudal)
	animGroup:insert(animPelvic)
	animGroup:insert(animAnalFin)
	animGroup:insert(animSoftRay)
	-- move animGroup(whole body) to -70 in x axis
	animGroup.x = -70

	sceneGroup:insert(animGroup)

--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

	-- Grabs the .wav files and set labels
	soundTable = {
       analSound = audio.loadSound ("analFin.wav"),
       softSound = audio.loadSound ("softRay.wav"),
       pelvicSound = audio.loadSound ("pelvicFin.wav"),
       caudalSound = audio.loadSound ("caudalFin.wav"),
       mouthSound = audio.loadSound ("mouth.wav"),
    }

--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	-- Radio Buttons test
	--
	-- Handle press events for the buttons
	function onSwitchPress( event )
	   local switch = event.target
	   print( "Switch with ID '"..switch.id.."' is on: "..tostring(switch.isOn) )
	end

	-- Create two associated radio buttons (inserted into the same display group)

	local button1 = display.newText("Touch", 170 ,500, native.systemFont, 40)
	button1.text = "Touch"

	sceneGroup:insert(button1) -- Inserts button1 to sceneGroup

	local button2 = display.newText("Slider", 170 ,580,native.systemFont, 40 )
	button2.text = "Slider"

	sceneGroup:insert(button2) -- Inserts button2 to sceneGroup
	--[[ 	- creates a rounded rectangle to be positioned around the two buttons that were created 
			- create radio buttons in order to turn on sliders or touch
	]]

	local myRoundedRect = display.newRoundedRect( 145, 535, 250, 180, 40 )
	myRoundedRect.strokeWidth = 10
	myRoundedRect:setFillColor( 0.0, 0, 0, 0 )
	myRoundedRect:setStrokeColor( 0.7, 0.7, 1, 0.6 )

	sceneGroup:insert(myRoundedRect)

	-- Create a group for the radio button set
	local radioGroup = display.newGroup()
	local radioButton1 = widget.newSwitch(
	   {
	    left = 45,
	    top = 480,
	    style = "radio",
	    id = "RadioButton1",
	    width = 50,
	    height = 50,
	    initialSwitchState = true,
	    onPress = onSwitchPress
	    
	   }
	)
	radioGroup:insert( radioButton1 )

	local radioButton2 = widget.newSwitch(
	  {
	   left = 45,
	   top = 555,
	   style = "radio",
	   id = "RadioButton2",
	   width = 50,
	   height = 50,
	   onPress = onSwitchPress
	  }
	)
	radioGroup:insert( radioButton2 )

	sceneGroup:insert(radioGroup.parent)

--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

	--[[ 	- Slider widget will be displayed here with x and y to determine placement on the screen as well as well as width of slider
			- Slider listener will grab the value to determine which frame will be displayed 
			- Display text to label each slider with position, font and color
			- 


	]]

	--[[ 	- slider listener for mouth
			- Depending on value from slider and how many frames the body part has 
			- if statements will be used to determine what frame will be shown
			]]

	function mouthListener(event)
	if (radioButton2.isOn) then
	print("Mouthslider at " .. event.value .. "%")
		if (event.value < 25 ) then 
				animMouth:setFrame("1")

			elseif (event.value > 26 and event.value < 50 ) then 
				animMouth:setFrame("2")

			elseif (event.value > 51 and event.value < 75 ) then 
				animMouth:setFrame(" 3")

			elseif (event.value > 76 ) then 	
				animMouth:setFrame( "4" )
		end
	else
		print("disabled")
	end
		return true
	end

	-- create the widget--
	local mouthslider = widget.newSlider(
	{
	  x = 800,
      y = 350,
	  width = 300,
	  value = 0, --start slider at 0%(optional)
	  listener = mouthListener
	})
	sceneGroup:insert(mouthslider)

	-- create text --
	local myMouth = display.newText( "Mouth", 580, 350, native.systemFont, 25 )
    myMouth:setFillColor( 1, 1, 1 )
    sceneGroup:insert(myMouth)

	-- slider listener for caudal --
	function caudalListener(event)
	if (radioButton2.isOn) then
	print("Caudalslider at " .. event.value .. "%")
		if (event.value < 20 ) then 
				animCaudal:setFrame("1")
			elseif (event.value > 21 and event.value < 40 ) then 
				animCaudal:setFrame("2")

			elseif (event.value > 41 and event.value < 60 ) then 
				animCaudal:setFrame(" 3")

			elseif (event.value > 61 and event.value < 80 ) then 	
				animCaudal:setFrame( "4" )

			elseif (event.value > 81 ) then 	
				animCaudal:setFrame( "5" )
		end
	else
		print("disabled")
	end
		return true
	end

	-- create the widget --
	local caudalslider = widget.newSlider(
	{
	  x = 800,
      y = 405,
	  width = 300,
	  value = 0, --start slider at 0%(optional)
	  listener = caudalListener
	})
	sceneGroup:insert(caudalslider)
	-- create text --
	local myCaudal = display.newText( "Caudal fin",560, 405, native.systemFont, 25 )
    myCaudal:setFillColor( 1, 1, 1 )
    sceneGroup:insert(myCaudal)

    -- slider listener for pelvic --

	function pelvicListener(event)
	if (radioButton2.isOn) then
	print("Pelvicslider at " .. event.value .. "%")
		if (event.value < 33 ) then 
			animPelvic:setFrame("1")
	
		elseif (event.value > 34 and event.value < 66 ) then 
			animPelvic:setFrame("2")

		elseif (event.value > 67 ) then 	
			animPelvic:setFrame( "3" )

		end
	else
		print("disabled")
	end
		return true
	end

	-- create the widget --
	local pelvicslider = widget.newSlider(
	{
	  x = 800,
      y = 465,
	  width = 300,
	  value = 0, --start slider at 0%(optional)
	  listener = pelvicListener
	})
	sceneGroup:insert(pelvicslider)
	-- create text --
	local myPelvic = display.newText( "Pelvic fin",565 , 465, native.systemFont, 25 )
    myPelvic:setFillColor( 1, 1, 1 )
    sceneGroup:insert(myPelvic)

    -- slider listener for analfin --
	function analfinListener(event)
	if (radioButton2.isOn) then
	print("AnalFinslider at " .. event.value .. "%")
		if (event.value < 50 ) then 
			animAnalFin:setFrame("1")

		elseif (event.value > 51 ) then 	
			animAnalFin:setFrame( "2" )

		end
	else
		print("disabled")
	end
		return true
	end

	-- create the widget --
	local analfinslider = widget.newSlider(
	{
	  x = 800,
      y = 510,
	  width = 300,
	  value = 0, --start slider at 0%(optional)
	  listener = analfinListener
	})
	sceneGroup:insert(analfinslider)
	-- create text --
	local myAnal = display.newText( "Anal fin",575 , 510, native.systemFont, 25 )
    myAnal:setFillColor( 1, 1, 1 )
    sceneGroup:insert(myAnal)

    -- slider listener for softray --
	function softrayListener(event)
	if (radioButton2.isOn) then
	print("SoftRayslider at " .. event.value .. "%")
		if (event.value < 33 ) then 
			animSoftRay:setFrame("1")

		elseif (event.value > 34 and event.value < 66 ) then 
			animSoftRay:setFrame("2")

		elseif (event.value > 67 ) then 	
			animSoftRay:setFrame( "3" )

		end
	else
		print("disabled")
	end
		return true
	end

	-- create the widget --
	local softrayslider = widget.newSlider(
	{
	  x = 800,
      y = 555,
	  width = 300,
	  value = 0, --start slider at 0%(optional)
	  listener = softrayListener,
	  orientation = "horizontal"
	})
	sceneGroup:insert(softrayslider)
	-- create text --
	local myRay = display.newText( "Soft ray",575 , 555, native.systemFont, 25 )
    myRay:setFillColor( 1, 1, 1 )
    sceneGroup:insert(myRay)

    -- slider listener for H. move --
	function moveListener(event)
	if (radioButton2.isOn) then
	print("Moveslider at " .. event.value .. "%")
		animGroup.x = (-370 + (event.value * 6.5))--1140 * (event.value/100)
	else
		print("disabled")
	end
	end

	-- create the widget --
	local moveslider = widget.newSlider(
	{
	  x = 800,
      y = 600,
	  width = 300,
	  value = 50, --start slider at 0%(optional)
	  listener = moveListener
	})
	sceneGroup:insert(moveslider)
	-- create text --
	local myHeight = display.newText( "H. move",570 , 600, native.systemFont, 25 )
    myHeight:setFillColor( 1, 1, 1 )
 	sceneGroup:insert(myHeight)


--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

 	--------the audio----------------------------------------------
 	--[[	- Event listeners for audio is set here. 
 				will play depending on which radio button is selected 



 	]]

 	-- mouth audio listener -- 
	function spriteAudioMouth(event)
		if (radioButton1.isOn) then
	      if ( event.phase == "began" ) then
		  audio.play( soundTable["mouthSound"]);
	      end	
	  	else
	  		print("disabled")
	  	end
	    return true
	end
	-- caudal audio listener -- 
	function spriteAudioCaudal(event)
		if (radioButton1.isOn) then
	      if ( event.phase == "began" ) then
		  audio.play( soundTable["caudalSound"]);
	      end	
	  	else
	  		print("disabled")
	  	end
	    return true
	end
	-- pelvic audio listener -- 
	function spriteAudioPelvic(event)
		if (radioButton1.isOn) then
	      if ( event.phase == "began" ) then
		  audio.play( soundTable["pelvicSound"]);
	      end
	    else
	  		print("disabled")
	  	end	
	    return true
	end
	-- anl fin audio listener -- 
	function spriteAudioAnal(event)
		if (radioButton1.isOn) then
	      if ( event.phase == "began" ) then
		  audio.play( soundTable["analSound"]);
	      end
	    else
	  		print("disabled")
	  	end		
	    return true
	end
	-- soft fin audio listener -- 
	function spriteAudioSoft(event)
		if (radioButton1.isOn) then
	      if ( event.phase == "began" ) then
		  audio.play( soundTable["softSound"]);
	      end
	    else
	  		print("disabled")
	  	end		
	    return true
	end

--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

-------play and stop animations------------------------------
	
	function spriteListener(event)

		local thisSprite = event.target  -- "event.target" references the sprite
	 		
		if (radioButton1.isOn) then
		 	if (backwards == false) then
		 		backwards = true
		 		thisSprite:setSequence( "mouthmoving" )
		 		thisSprite:setSequence( "cadualmoving" )
		 		thisSprite:setSequence( "pelvicmoving" )
		 		thisSprite:setSequence( "analmoving" )
		 		thisSprite:setSequence( "softraymoving" )
		 		thisSprite:play()
		 	else
		 		backwards = false
		 		thisSprite:setSequence("mouthback")
		 		thisSprite:setSequence( "cadualback" )
		 		thisSprite:setSequence( "pelvicback" )
		 		thisSprite:setSequence( "analback" )
		 		thisSprite:setSequence( "softrayback" )
		 		thisSprite:play()
		 	end
	    
		else
			print("disabled")
		end
		return true
	end
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

--[[	- Transition for part 3 is implemented here
		- timer perform with delay was used to get KingFossil to be moved up and down
		- Used an easing function

]]
	local function mainListener( event)
      	
      	transition.to( animGroup,{ time = 350, delay= 0 , y= -2.5, transition= easing.inSine })

   		transition.to( animGroup,{ time = 350, delay= 350 , y= 2.5, transition= easing.inSine })
   	end
   		
   	timer.performWithDelay( 1050, mainListener,0 )

--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

	-- All of the event listeners were added here for sprite animation and to play audio

	animMouth:addEventListener( "tap", spriteListener )
	animMouth:addEventListener( "touch", spriteAudioMouth )
	animCaudal:addEventListener( "tap", spriteListener )
	animCaudal:addEventListener( "touch", spriteAudioCaudal )
	animPelvic:addEventListener( "tap", spriteListener )
	animPelvic:addEventListener( "touch", spriteAudioPelvic )
	animAnalFin:addEventListener( "tap", spriteListener )
	animAnalFin:addEventListener( "touch", spriteAudioAnal )
	animSoftRay:addEventListener( "tap", spriteListener )
	animSoftRay:addEventListener( "touch", spriteAudioSoft )
end



-- "scene:show()"
function scene:show( event )
 
   	local sceneGroup = self.view
   	local phase = event.phase
 
   	if ( phase == "will" ) then
      -- Called when the scene is still off screen (but is about to come on screen).
   

   	elseif ( phase == "did" ) then
      -- Called when the scene is now on screen.
      -- Insert code here to make the scene come alive.
      -- Example: start timers, begin animation, play audio, etc.


   	end
end
 
-- "scene:hide()"
function scene:hide( event )
 
   local sceneGroup = self.view
   local phase = event.phase
 
   if ( phase == "will" ) then
      -- Called when the scene is on screen (but is about to go off screen).
      -- Insert code here to "pause" the scene.
      -- Example: stop timers, stop animation, stop audio, etc.
   elseif ( phase == "did" ) then
      -- Called immediately after scene goes off screen.
   end
end
 
-- "scene:destroy()"
function scene:destroy( event )
 
   local sceneGroup = self.view
 
   -- Called prior to the removal of scene's view ("sceneGroup").
   -- Insert code here to clean up the scene.
   -- Example: remove display objects, save state, etc.
end
 
---------------------------------------------------------------------------------
 
-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
 
---------------------------------------------------------------------------------
  
return scene
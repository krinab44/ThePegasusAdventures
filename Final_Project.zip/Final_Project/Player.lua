local Collideable = require("Collideable");
local Player = Collideable:new({xPos = 50, yPos = display.contentCenterY, deltaX = 0, deltaY = -300, tag = "Player", physicsType = "dynamic", HP = 3});

--insert sprite options here
local opt = {
   	frames = {
		{ x = 743, y = 130, width = 603, height = 451}, -- 1. Buttercup 1
 		{ x = 1447, y = 130, width = 603, height = 451}, -- 2. Buttercup 2
      	{ x = 2151, y = 130, width = 603, height = 451}, -- 3. Buttercup 3

   	    { x = 4266, y = 130, width = 603, height = 451}, -- 4. Snowflake  1
   	    { x = 741, y = 832, width = 603, height = 446}, -- 5. Snowflake  2
   	    { x = 1449, y = 832, width = 603, height = 446}, -- 6. Snowflake  3

  		{ x = 2853, y = 832, width = 603, height = 446}, -- 7. Pumpkin 1
    	{ x = 3560, y = 832, width = 603, height = 446}, -- 8. Pumpkin 2
    	{ x = 4262, y = 832, width = 603, height = 446}, -- 9. Pumpkin 3
    }
}

Butter_sequenceData = {
    {name = "butterFlying", frames = {1, 2, 3, 2}, time = 1800, loopCount = 0}
} 
Snow_sequenceData = {
    {name = "snowFlying", frames = {4, 5, 6, 5}, time = 1800, loopCount = 0}
}  
Pumpkin_sequenceData = {
    {name = "pumpkinFlying", frames = {7, 8, 9, 8}, time = 1800, loopCount = 0}
}  

local sheet = graphics.newImageSheet("world.png", opt);
local animations = display.newSprite(sheet, Butter_sequenceData);

function Player:spawn()
    self.shape = animations;
    self.shape.xScale = 0.1;
    self.shape.yScale = 0.1;
    if(self.theme == "princess") then
        self.shape:setSequence("butterFlying");
    elseif(self.theme == "pumpkin") then
        self.shape:setSequence("pumpkinFlying");
    elseif(self.theme == "snowflake") then
        self.shape:setSequence("snowFlying");
    end
    self.shape.pp = self;
    self.shape.tag = self.tag;
    self.shape.x = self.xPos;
    self.shape.y = self.yPos;
    physics.addBody(self.shape, self.physicsType);

    local function playerCollision(event)
        if(event.phase == "began") then
            if(event.other.tag == "Obstacle") then
                self:collide();
                self.HP = self.HP - 1;
            elseif(event.other.tag == "Collectable") then
                self:collect();
                Score = Score + 100;
            end
        end
    end
    self.shape:addEventListener("collision", playerCollision);
end

function Player:flap()
    self.shape:applyForce(self.deltaX, self.deltaY, self.shape.x, self.shape.y);
end

physics.start();
return Player;